''' by Elaine S. Andus BSCS 3AB '''

from flask import Flask, render_template
app = Flask(__name__)


@app.route('/')
def hello_world():
    return 'Hello World!' 


@app.route('/dojo')
def home_page():
    return 'Dojo!'


@app.route('/say/<name>')
def hello_user(name):
    return 'Hi ' + name + '!'


@app.route('/repeat/<name>/<times>')
def repeat_greet(name,times):
    times=int(times)
    return render_template('index.html',len=times,getName=name)


if __name__=="__main__":
    app.run(debug=True)