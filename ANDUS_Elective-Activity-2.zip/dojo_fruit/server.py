''' by Elaine S. Andus BSCS 3AB '''

from flask import Flask, render_template, redirect, request, session

app = Flask(__name__)
app.secret_key="keep it secret, keep it safe"


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/checkout', methods=['POST'])
def users():
    print("Got Post Info")
    session['strawberry']=request.form['strawberry']
    session['raspberry']=request.form['raspberry']
    session['apple']=request.form['apple']
    session['firstName']=request.form['first_name']
    session['studentId']=request.form['student_id']
    return render_template('show.html',all_firstName=session['firstName'], all_studentId=session['studentId'],all_strawberry=session['strawberry'],all_raspberry=session['raspberry'],all_apple=session['apple'])


if __name__=="__main__":
    app.run(debug=True)